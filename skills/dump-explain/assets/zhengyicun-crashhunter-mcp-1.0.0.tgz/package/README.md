# CrashHunter MCP

CrashHunter 崩溃分析工具包 —— 支持作为 **MCP Server** 或 **Skill（CLI）** 两种方式使用，帮助 AI 快速获取并分析 CrashHunter (UniSDK) 平台上的崩溃 dump 信息。

## ✨ 功能特性

- **崩溃堆栈获取**：自动获取崩溃线程的完整堆栈、设备信息和局部变量
- **崩溃文件下载**：自动下载崩溃关联文件（日志、崩溃参数、设备详情、minidump、全量压缩包等），文本文件内容直接返回供 AI 分析
- **Tombstone 分析**：针对 Android Native Crash，提取 tombstone 中的 Maps（加载的 so 库）、FD（文件描述符）、线程和函数引用等信息
- **浏览器登录**：自动打开浏览器窗口，完成 SSO 认证并捕获 Cookie
- **Cookie 持久化**：登录凭据保存在本地 (`~/.crashhunter_mcp/cookies.json`)，无需重复登录
- **自动签名**：自动处理 HmacMD5 请求签名 (`x-sign-token`)
- **智能输出**：仅输出崩溃线程堆栈和前 10 帧局部变量，避免上下文溢出
- **过期检测**：自动检测 Cookie 过期并触发重新登录

## 📁 项目结构

```
src/
├── core/           # 核心业务逻辑（可独立使用的库）
│   ├── index.ts    # 库入口 & 对外 API（getCrashInfo / getCrashFiles / getTombstoneInfo）
│   ├── api.ts      # HTTP 接口调用（identify-list / parsecrash / localvar / crapi / download）
│   ├── browser.ts  # Puppeteer 浏览器登录
│   ├── cookies.ts  # Cookie 持久化管理
│   ├── format.ts   # 崩溃报告格式化
│   ├── http.ts     # HTTP 请求 & HmacMD5 签名 & 文件下载
│   ├── parser.ts   # URL 解析
│   ├── log.ts      # 日志工具
│   └── types.ts    # 类型定义
├── mcp/            # MCP Server 入口
│   └── index.ts
└── cli/            # CLI 入口（供 Skill 调用）
    └── index.ts
```

## 🔧 安装与构建

### 自动源码构建

* `git clone <repo-url>`

* `cd crashhunter-mcp`

* 运行build.bat即可, 可以选择npm还是pnpm, 如果是pnpm会塞到系统目录后面用这个方式调用即可

    ```json
    {
      "mcpServers": {
        "crashhunter": {
          "command": "crashhunter-mcp"
        }
      }
    }
    ```

    根据实际使用,  可能需要 `npx puppeteer browsers install chrome` , 也一并加到build.bat了

### 手工源码构建

```bash
git clone <repo-url>
cd crashhunter-mcp
npm install
npm run build
```

构建完成后会在 `dist/` 目录生成编译产物。

### 本地全局链接（可选）

如果希望在终端中直接使用 `crashhunter-mcp` 和 `crashhunter` 命令：

```bash
npm link
```

执行后将注册以下两个全局命令：
- `crashhunter-mcp` — 启动 MCP Server
- `crashhunter` — CLI 工具（用于 Skill 调用）

### 更新已安装的版本

如果之前已经安装过，拉取最新代码后重新构建即可：

```bash
cd crashhunter-mcp
git pull
npm install
npm run build
```

或直接运行 `build.bat`。

> 无需重新执行 `npm link`，已有的全局命令会自动指向新构建的产物。  
> 如果使用 MCP Server 方式，更新后需要**重启 MCP Server**（或重启 AI 客户端）才能加载新功能。

---

## 🚀 使用方式一：MCP Server

将 CrashHunter 作为 MCP Server 加载到支持 MCP 协议的 AI 客户端（如 Claude Desktop、CodeMaker 等），AI 可直接调用工具进行崩溃分析。

### 配置方法

在 MCP 客户端的配置文件中添加：

#### 方式 A：已执行 `npm link`（推荐）

```json
{
  "mcpServers": {
    "crashhunter": {
      "command": "crashhunter-mcp"
    }
  }
}
```

#### 方式 B：使用绝对路径

```json
{
  "mcpServers": {
    "crashhunter": {
      "command": "node",
      "args": ["/your/path/to/crashhunter-mcp/dist/mcp/index.js"]
    }
  }
}
```

> 请将路径替换为你本机的实际项目路径。

### MCP 提供的工具

#### `login`

打开浏览器窗口进行 SSO 认证。首次使用或 Cookie 过期时需要调用。

| 参数    | 类型   | 必填 | 说明                           |
|---------|--------|------|--------------------------------|
| project | string | 否   | 项目名称（默认：hzengine）     |

#### `get_crash_detail`

根据 dump URL 获取崩溃详细信息，返回格式化的 Markdown 报告（包括堆栈、设备信息、局部变量）。

| 参数               | 类型    | 必填 | 说明                             |
|--------------------|---------|------|----------------------------------|
| url                | string  | 是   | dump 页面完整 URL                |
| include_local_vars | boolean | 否   | 是否包含局部变量（默认：true）   |

#### `download_crash_files`

下载崩溃关联的附件文件，文本文件内容直接返回，二进制文件可选保存到磁盘。

| 参数       | 类型   | 必填 | 说明                                                     |
|------------|--------|------|----------------------------------------------------------|
| url        | string | 是   | dump 页面完整 URL（同 `get_crash_detail`）               |
| output_dir | string | 否   | 文件保存目录；如不指定，仅返回文本文件内容               |

**可获取的文件类型：**

| 文件类型 | 说明 | AI 分析价值 |
|---------|------|------------|
| **All Crash Files (zip)** | 所有文件的打包合集 | 一次性下载所有文件，方便人工备份 |
| **di** | 设备详细信息 | CPU 频率、内存详情、启动时间、崩溃时间等 |
| **tombstone** | Android tombstone 文件 | 二进制 Protobuf（Android 12+），包含内存映射、FD 等 |
| **dmp** | Windows/Android minidump | 二进制文件，需 WinDbg 或专用工具分析 |
| **UniTrace.log / log.txt** | 崩溃前日志 | 运行日志，包含关键错误和状态变化 |
| **crashHunterParam.txt** | 崩溃上报参数 | 客户端版本、引擎版本、用户 ID 等 |
| **{identify}-analyze** | minidump 完整分析报告 | 所有线程的堆栈、寄存器值、加载模块列表（仅保存到磁盘，不内联） |

#### `get_tombstone_info`

获取 Android 崩溃的 Tombstone 详细信息（从 Protobuf 二进制中提取可读内容）。

| 参数     | 类型     | 必填 | 说明                                                      |
|----------|----------|------|-----------------------------------------------------------|
| url      | string   | 是   | dump 页面完整 URL                                         |
| sections | string[] | 否   | 要获取的信息段：`maps`、`fd`、`memory_near`、`threads`   |

**提取的信息：**

| 信息段 | 说明 | 分析价值 |
|--------|------|----------|
| **maps** | 加载的 so 库列表 | 判断崩溃时哪些库被加载，地址范围是否正常 |
| **fd** | 打开的文件描述符 | 检测是否有文件描述符泄露（socket、pipe、设备文件等） |
| **threads** | 线程名与函数引用 | 了解崩溃时的线程状态、调用链信息 |

### MCP 使用流程

1. AI 客户端加载 MCP Server 后，用户提供 dump URL
2. AI 调用 `get_crash_detail` 获取崩溃堆栈和设备信息
3. AI 调用 `download_crash_files` 下载关联文件（日志、崩溃参数等）获取更多上下文
4. （Android 崩溃）AI 调用 `get_tombstone_info` 获取 Maps/FD/线程等信息辅助分析
5. 如果提示未登录，AI 调用 `login` 工具，用户在弹出的浏览器中完成 SSO 登录
6. AI 综合堆栈信息、关联文件和 tombstone 信息，分析崩溃原因并给出修复建议

---

## 🛠 使用方式二：Skill（CLI）

将 CrashHunter 作为 Skill 使用，AI 通过终端命令调用 CLI 工具完成崩溃分析。这种方式**无需配置 MCP Server**，只需将 Skill 文档提供给 AI 即可。

### Skill 文档

Skill 定义文件位于 [`docs/skill-crashhunter.md`](docs/skill-crashhunter.md)，可在支持 Skill 的 AI 环境中加载。

### CLI 命令

> 由于包尚未发布到 npm，需要先克隆仓库并执行 `npm link` 注册全局命令（详见上方"安装与构建"部分）。

#### 登录

```bash
crashhunter login
crashhunter login <项目名>
```

#### 分析崩溃

```bash
crashhunter analyze "<dump_url>"
crashhunter analyze "<dump_url>" --no-local-vars
```

#### 下载崩溃关联文件

```bash
crashhunter download "<dump_url>"
crashhunter download "<dump_url>" --output-dir ./crash_files
```

#### 获取 Tombstone 详情（Android）

```bash
crashhunter tombstone "<dump_url>"
crashhunter tombstone "<dump_url>" --sections maps,fd
```

> ⚠️ **URL 必须用引号包裹**，因为 URL 中包含 `&` 等 Shell 特殊字符。

### Skill 使用流程

1. 在 AI 环境中加载 `docs/skill-crashhunter.md` Skill 文档
2. 用户提供 dump URL，AI 根据 Skill 指引通过终端执行 CLI 命令
3. AI 先执行 `analyze` 获取堆栈，再执行 `download` 获取关联文件
4. （Android 崩溃）AI 执行 `tombstone` 获取 Maps/FD/线程等信息
5. 如果提示"未登录或登录已过期"，AI 会引导执行 `login` 命令
6. AI 综合堆栈信息和关联文件内容进行深度分析并输出结论

---

## 🔄 两种方式对比

| 特性         | MCP Server                      | Skill（CLI）                       |
|--------------|----------------------------------|------------------------------------|
| 通信方式     | Stdio 协议，AI 直接调用工具     | AI 通过终端执行命令                |
| 配置要求     | 需在 MCP 客户端配置 Server      | 加载 Skill 文档即可               |
| 适用场景     | 深度集成、常驻使用               | 灵活调用、无需预配置              |
| 登录触发     | AI 自动调用 login 工具           | AI 引导用户执行 login 命令        |
| 输出格式     | 通过 MCP 协议返回结构化内容      | 通过终端标准输出返回文本          |
| 环境要求     | 支持 MCP 的 AI 客户端           | 支持终端命令执行的 AI 环境        |

---

## 📋 Dump URL 格式

```
https://unisdk.nie.netease.com/appdump/{project}/identify-detail?identify=xxx&time=xxx-xxx
```

示例：
```
https://unisdk.nie.netease.com/appdump/hzengine/identify-detail?identify=abc123&time=1700000000-1700100000
```

## ⚙️ 工作原理

1. **登录**：通过 Puppeteer 打开浏览器，用户手动完成 SSO 登录，自动捕获 Cookie（包括 httpOnly）并持久化
2. **URL 解析**：从 dump URL 中提取项目名、identify hash 和时间范围
3. **identify-list API**：获取 dump 元数据，包括 ES 文档的 `_id`、`_index` 和 `files` 字段（使用 HmacMD5 签名）
4. **parsecrash API**：获取解析后的堆栈信息（仅崩溃线程）
5. **parselocalvar API**：获取结构化的局部变量数据（前 10 帧）
6. **download API**：通过 `/api/appdump/api/v2/crapi/download` 下载崩溃关联文件（zip 全量包、tombstone、di、dmp、other）
7. **tombstone API**：通过 `download?download=false&type=tombstone` 获取 tombstone 文本内容，从 Protobuf 二进制中提取可读的 ASCII 字符串（库路径、线程名、函数名、文件描述符等）
8. **analyze 文件**：从 crash API 的 `stack_trace` 字段获取完整的 minidump_stackwalk 输出（所有线程堆栈 + 寄存器 + 加载模块），即网页上 `{identify}-analyze` blob 文件的内容
9. **智能输出**：文本文件（`.txt`、`.log`、`.di` 等）内容直接返回给 AI；大文件（analyze ~700KB）和二进制文件（`.dmp`、`.zip`、`.tombstone`）仅保存到磁盘
10. **格式化输出**：返回 Markdown 格式的崩溃分析报告

## 📦 环境要求

- Node.js >= 18
- Chrome / Chromium 浏览器（Puppeteer 会使用其内置版本）
- 可访问 `unisdk.nie.netease.com` 的网络环境

## 📄 License

MIT